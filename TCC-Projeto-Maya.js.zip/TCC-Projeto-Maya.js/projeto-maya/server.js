import app from './src/app.js';
import path from 'path';

const port = process.env.PORT || 80;

// Adiciona rota para servir a página HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Servidor escutando em http://localhost:${port}`);
});