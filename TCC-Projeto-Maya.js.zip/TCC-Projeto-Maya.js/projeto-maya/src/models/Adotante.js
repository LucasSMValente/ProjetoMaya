import mongoose from "mongoose";

const adotanteSchema = new mongoose.Schema({
    id: { type: String },
    nome: { type: String , required: true  },
    telefone: { type: String},
    cachorros: { type: String },
    preferencial: {type: Boolean},
    formulario: {type: Boolean},
    insertdate: {type: Date},
    smsdate: {type: String},
});
const Adotante = mongoose.model('adotantes', adotanteSchema);

export default Adotante;