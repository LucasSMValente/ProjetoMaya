import mongoose from "mongoose";

mongoose.connect("mongodb+srv://admin:admin@projeto-maya.kbkeofe.mongodb.net/");

let db = mongoose.connection;

export default db;