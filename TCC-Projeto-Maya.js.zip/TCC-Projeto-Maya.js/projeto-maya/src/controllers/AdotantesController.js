import adotantes from "../models/Adotante.js"

class AdotantesController {
    static listarAdotantes = async (req, res) =>{
        try {
            const adotantesResultado = await adotantes.find()
            res.status(200).json(adotantesResultado)
        } catch (err) {
            res.status(500).json(err)
        }
    }


    static cadastrarAdotantes = async (req, res) => {
        try {
            let novoAdotante = new adotantes(req.body); // Alterado para "novoAdotante"
            await novoAdotante.save(); // Alterado para "novoAdotante"
            res.status(200).send({ message: 'Adotante cadastrado com sucesso.' });
        } catch (err) {
            res.status(500).json(err);
        }
    }

    static atualizarAdotantes = async (req, res) => {
        try {
            const { nome, smsdate } = req.body;
    
            if (!nome || !smsdate) {
                return res.status(400).send({ message: 'Parâmetros inválidos.' });
            }
    
            // Use o método findOneAndUpdate do Mongoose para encontrar e atualizar o documento
            const resultado = await adotantes.findOneAndUpdate({ nome }, { smsdate }, { new: true });
    
            if (resultado) {
                res.status(200).send({ message: `Campo smsdate para ${nome} atualizado com sucesso.`, data: resultado });
            } else {
                res.status(404).send({ message: 'Adotante não encontrado.' });
            }
        } catch (err) {
            console.error(err);
            res.status(500).json({ message: 'Erro ao atualizar adotante.' });
        }
    }

   static removerAdotante = async (req, res) => {
        try {
            const nome = req.params.nome;  // Alterado para utilizar o nome ao invés do id
            const resultado = await adotantes.findOneAndRemove({ nome });

            if (resultado) {
                res.status(200).send({ message: 'Adotante removido com sucesso.' });
            } else {
                res.status(404).send({ message: 'Adotante não encontrado.' });
            }
        } catch (err) {
            res.status(500).json(err);
        }
    }
}

export default AdotantesController

//Controla as funções.