import express from "express";
import db from "./config/dbConnect.js";
import routes from "./routes/index.js"
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

db.on("error", console.log.bind(console, 'Erro de conexão.'))
db.once("open", () =>{
    console.log('conexão com o banco bem sucedida.')
})

const app = express();

// Configura o Express para servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use(express.json());
routes(app);

export default app