import express from "express";
import AdotantesController from "../controllers/AdotantesController.js";

const router = express.Router();

router
    .get('/adotante', AdotantesController.listarAdotantes)
    .post('/Adotantes', AdotantesController.cadastrarAdotantes)
    .post('/AtualizarAdotantes/:nome',AdotantesController.atualizarAdotantes)
    .delete('/Adotantes/:nome', AdotantesController.removerAdotante)

export default router;