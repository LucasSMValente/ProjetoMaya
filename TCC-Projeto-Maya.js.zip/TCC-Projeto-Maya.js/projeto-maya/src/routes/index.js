import express from "express";
import adotantes from "./adotantesRoutes.js"

const routes = (app) => {
    app.route('/').get((req, res) => {
    res.status(200).send({titulo: "Adoção - Projeto Maya"})
    })

app.use(
    express.json(),
    adotantes
    )
}

export default routes